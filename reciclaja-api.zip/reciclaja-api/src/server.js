'use strict';

require('./database/init'); // garante que as tabelas existam
const app = require('./app');
const { env } = require('./config/env');

app.listen(env.PORT, () => {
  console.log(`🚀 ReciclaJá API rodando em http://localhost:${env.PORT}`);
  console.log(`   Ambiente: ${env.NODE_ENV}`);
});
