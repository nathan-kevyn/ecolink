'use strict';

const service = require('./ponto.service');

function listar(req, res, next) {
  try {
    // Filtros opcionais via query string: ?cidade=São Paulo&ativo=true
    const filtros = {};
    if (req.query.cidade) filtros.cidade = req.query.cidade;
    if (req.query.ativo !== undefined) filtros.ativo = req.query.ativo === 'true';
    res.json(service.listar(filtros));
  } catch (err) {
    next(err);
  }
}

function buscar(req, res, next) {
  try {
    res.json(service.buscarPorId(Number(req.params.id)));
  } catch (err) {
    next(err);
  }
}

function criar(req, res, next) {
  try {
    res.status(201).json(service.criar(req.body));
  } catch (err) {
    next(err);
  }
}

function atualizar(req, res, next) {
  try {
    res.json(service.atualizar(Number(req.params.id), req.body));
  } catch (err) {
    next(err);
  }
}

function remover(req, res, next) {
  try {
    service.remover(Number(req.params.id));
    res.status(204).end();
  } catch (err) {
    next(err);
  }
}

module.exports = { listar, buscar, criar, atualizar, remover };
