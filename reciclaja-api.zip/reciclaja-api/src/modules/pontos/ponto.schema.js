'use strict';

const { z } = require('zod');

const createPontoSchema = z.object({
  nome: z.string().min(2).max(120),
  endereco: z.string().min(3).max(200),
  cidade: z.string().min(2).max(80),
  latitude: z.number().min(-90).max(90).optional(),
  longitude: z.number().min(-180).max(180).optional(),
  materiais: z.array(z.string().min(1)).optional(),
  horario: z.string().max(120).optional(),
  ativo: z.boolean().optional(),
});

const updatePontoSchema = createPontoSchema.partial();

module.exports = { createPontoSchema, updatePontoSchema };
