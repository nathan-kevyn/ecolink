'use strict';

const db = require('../../config/database');

// Converte a linha crua do banco para um objeto amigável da API.
function paraObjeto(row) {
  if (!row) return row;
  return {
    ...row,
    materiais: JSON.parse(row.materiais || '[]'),
    ativo: Boolean(row.ativo),
  };
}

function findAll(filtros = {}) {
  let sql = 'SELECT * FROM pontos_coleta';
  const where = [];
  const params = [];

  if (filtros.cidade) {
    where.push('cidade = ?');
    params.push(filtros.cidade);
  }
  if (filtros.ativo !== undefined) {
    where.push('ativo = ?');
    params.push(filtros.ativo ? 1 : 0);
  }
  if (where.length) sql += ' WHERE ' + where.join(' AND ');
  sql += ' ORDER BY id';

  return db.prepare(sql).all(...params).map(paraObjeto);
}

function findById(id) {
  return paraObjeto(
    db.prepare('SELECT * FROM pontos_coleta WHERE id = ?').get(id)
  );
}

function create(d) {
  const info = db
    .prepare(
      `INSERT INTO pontos_coleta
        (nome, endereco, cidade, latitude, longitude, materiais, horario, ativo)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      d.nome,
      d.endereco,
      d.cidade,
      d.latitude ?? null,
      d.longitude ?? null,
      JSON.stringify(d.materiais ?? []),
      d.horario ?? null,
      d.ativo === false ? 0 : 1
    );
  return findById(Number(info.lastInsertRowid));
}

function update(id, d) {
  const sets = [];
  const valores = [];

  for (const campo of ['nome', 'endereco', 'cidade', 'latitude', 'longitude', 'horario']) {
    if (d[campo] !== undefined) {
      sets.push(`${campo} = ?`);
      valores.push(d[campo]);
    }
  }
  if (d.materiais !== undefined) {
    sets.push('materiais = ?');
    valores.push(JSON.stringify(d.materiais));
  }
  if (d.ativo !== undefined) {
    sets.push('ativo = ?');
    valores.push(d.ativo ? 1 : 0);
  }

  if (sets.length) {
    db.prepare(
      `UPDATE pontos_coleta SET ${sets.join(', ')}, atualizado_em = datetime('now') WHERE id = ?`
    ).run(...valores, id);
  }
  return findById(id);
}

function remove(id) {
  return db.prepare('DELETE FROM pontos_coleta WHERE id = ?').run(id).changes > 0;
}

module.exports = { findAll, findById, create, update, remove };
