'use strict';

const { Router } = require('express');
const ctrl = require('./ponto.controller');
const validate = require('../../middlewares/validate');
const { createPontoSchema, updatePontoSchema } = require('./ponto.schema');

const router = Router();

router.get('/', ctrl.listar); // GET    /api/pontos
router.get('/:id', ctrl.buscar); // GET    /api/pontos/:id
router.post('/', validate(createPontoSchema), ctrl.criar); // POST   /api/pontos
router.put('/:id', validate(updatePontoSchema), ctrl.atualizar); // PUT    /api/pontos/:id
router.delete('/:id', ctrl.remover); // DELETE /api/pontos/:id

module.exports = router;
