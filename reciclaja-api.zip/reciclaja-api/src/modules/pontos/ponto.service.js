'use strict';

const repo = require('./ponto.repository');
const ApiError = require('../../utils/ApiError');

function listar(filtros) {
  return repo.findAll(filtros);
}

function buscarPorId(id) {
  const ponto = repo.findById(id);
  if (!ponto) throw ApiError.notFound('Ponto de coleta não encontrado');
  return ponto;
}

function criar(dados) {
  return repo.create(dados);
}

function atualizar(id, dados) {
  buscarPorId(id);
  return repo.update(id, dados);
}

function remover(id) {
  buscarPorId(id);
  repo.remove(id);
}

module.exports = { listar, buscarPorId, criar, atualizar, remover };
