'use strict';

const { z } = require('zod');

const createUsuarioSchema = z.object({
  nome: z.string().min(2, 'nome deve ter ao menos 2 caracteres').max(120),
  email: z.string().email('e-mail inválido'),
  senha: z.string().min(6, 'senha deve ter ao menos 6 caracteres').max(72),
  telefone: z.string().max(20).optional(),
  cidade: z.string().max(80).optional(),
});

// No update todos os campos são opcionais (envia só o que quer alterar).
const updateUsuarioSchema = createUsuarioSchema.partial();

module.exports = { createUsuarioSchema, updateUsuarioSchema };
