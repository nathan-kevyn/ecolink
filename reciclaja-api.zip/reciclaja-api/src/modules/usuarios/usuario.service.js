'use strict';

const bcrypt = require('bcryptjs');
const repo = require('./usuario.repository');
const ApiError = require('../../utils/ApiError');

async function listar() {
  return repo.findAll();
}

async function buscarPorId(id) {
  const usuario = repo.findById(id);
  if (!usuario) throw ApiError.notFound('Usuário não encontrado');
  return usuario;
}

async function criar(dados) {
  if (repo.findByEmail(dados.email)) {
    throw ApiError.conflict('E-mail já cadastrado');
  }
  const senha_hash = await bcrypt.hash(dados.senha, 10);
  return repo.create({
    nome: dados.nome,
    email: dados.email,
    senha_hash,
    telefone: dados.telefone,
    cidade: dados.cidade,
  });
}

async function atualizar(id, dados) {
  await buscarPorId(id); // garante que existe (lança 404 se não)

  if (dados.email) {
    const existente = repo.findByEmail(dados.email);
    if (existente && existente.id !== id) {
      throw ApiError.conflict('E-mail já cadastrado por outro usuário');
    }
  }

  const campos = { ...dados };
  if (dados.senha) {
    campos.senha_hash = await bcrypt.hash(dados.senha, 10);
    delete campos.senha;
  }

  return repo.update(id, campos);
}

async function remover(id) {
  await buscarPorId(id);
  repo.remove(id);
}

module.exports = { listar, buscarPorId, criar, atualizar, remover };
