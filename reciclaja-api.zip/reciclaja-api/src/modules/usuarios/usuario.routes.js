'use strict';

const { Router } = require('express');
const ctrl = require('./usuario.controller');
const validate = require('../../middlewares/validate');
const {
  createUsuarioSchema,
  updateUsuarioSchema,
} = require('./usuario.schema');

const router = Router();

router.get('/', ctrl.listar); // GET    /api/usuarios
router.get('/:id', ctrl.buscar); // GET    /api/usuarios/:id
router.post('/', validate(createUsuarioSchema), ctrl.criar); // POST   /api/usuarios
router.put('/:id', validate(updateUsuarioSchema), ctrl.atualizar); // PUT    /api/usuarios/:id
router.delete('/:id', ctrl.remover); // DELETE /api/usuarios/:id

module.exports = router;
