'use strict';

const db = require('../../config/database');

// Nunca expomos a senha_hash nas leituras.
const CAMPOS_PUBLICOS =
  'id, nome, email, telefone, cidade, criado_em, atualizado_em';

function findAll() {
  return db.prepare(`SELECT ${CAMPOS_PUBLICOS} FROM usuarios ORDER BY id`).all();
}

function findById(id) {
  return db
    .prepare(`SELECT ${CAMPOS_PUBLICOS} FROM usuarios WHERE id = ?`)
    .get(id);
}

/** Inclui senha_hash — uso interno (verificação de e-mail/login). */
function findByEmail(email) {
  return db.prepare('SELECT * FROM usuarios WHERE email = ?').get(email);
}

function create({ nome, email, senha_hash, telefone, cidade }) {
  const info = db
    .prepare(
      `INSERT INTO usuarios (nome, email, senha_hash, telefone, cidade)
       VALUES (?, ?, ?, ?, ?)`
    )
    .run(nome, email, senha_hash, telefone ?? null, cidade ?? null);
  return findById(Number(info.lastInsertRowid));
}

function update(id, campos) {
  const permitidos = ['nome', 'email', 'senha_hash', 'telefone', 'cidade'];
  const chaves = Object.keys(campos).filter((k) => permitidos.includes(k));
  if (chaves.length === 0) return findById(id);

  const setSql = chaves.map((k) => `${k} = ?`).join(', ');
  const valores = chaves.map((k) => campos[k]);

  db.prepare(
    `UPDATE usuarios SET ${setSql}, atualizado_em = datetime('now') WHERE id = ?`
  ).run(...valores, id);

  return findById(id);
}

function remove(id) {
  const info = db.prepare('DELETE FROM usuarios WHERE id = ?').run(id);
  return info.changes > 0;
}

module.exports = { findAll, findById, findByEmail, create, update, remove };
