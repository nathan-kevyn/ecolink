'use strict';

const { Router } = require('express');
const ctrl = require('./coleta.controller');
const validate = require('../../middlewares/validate');
const { createColetaSchema, updateColetaSchema } = require('./coleta.schema');

const router = Router();

router.get('/', ctrl.listar); // GET    /api/coletas
router.get('/:id', ctrl.buscar); // GET    /api/coletas/:id
router.post('/', validate(createColetaSchema), ctrl.criar); // POST   /api/coletas
router.put('/:id', validate(updateColetaSchema), ctrl.atualizar); // PUT    /api/coletas/:id
router.delete('/:id', ctrl.remover); // DELETE /api/coletas/:id

module.exports = router;
