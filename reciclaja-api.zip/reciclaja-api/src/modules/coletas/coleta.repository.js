'use strict';

const db = require('../../config/database');

// Traz, junto da coleta, o nome do usuário e do ponto (JOIN).
const BASE = `
  SELECT
    c.id, c.usuario_id, c.ponto_id, c.material, c.quantidade_kg,
    c.status, c.data_agendada, c.criado_em, c.atualizado_em,
    u.nome AS usuario_nome,
    p.nome AS ponto_nome
  FROM coletas c
  JOIN usuarios u      ON u.id = c.usuario_id
  JOIN pontos_coleta p ON p.id = c.ponto_id
`;

function findAll(filtros = {}) {
  let sql = BASE;
  const where = [];
  const params = [];

  if (filtros.usuario_id) {
    where.push('c.usuario_id = ?');
    params.push(filtros.usuario_id);
  }
  if (filtros.ponto_id) {
    where.push('c.ponto_id = ?');
    params.push(filtros.ponto_id);
  }
  if (filtros.status) {
    where.push('c.status = ?');
    params.push(filtros.status);
  }
  if (where.length) sql += ' WHERE ' + where.join(' AND ');
  sql += ' ORDER BY c.id';

  return db.prepare(sql).all(...params);
}

function findById(id) {
  return db.prepare(`${BASE} WHERE c.id = ?`).get(id);
}

function create(d) {
  const info = db
    .prepare(
      `INSERT INTO coletas
        (usuario_id, ponto_id, material, quantidade_kg, status, data_agendada)
       VALUES (?, ?, ?, ?, ?, ?)`
    )
    .run(
      d.usuario_id,
      d.ponto_id,
      d.material,
      d.quantidade_kg ?? 0,
      d.status ?? 'agendada',
      d.data_agendada ?? null
    );
  return findById(Number(info.lastInsertRowid));
}

function update(id, d) {
  const sets = [];
  const valores = [];

  for (const campo of [
    'usuario_id',
    'ponto_id',
    'material',
    'quantidade_kg',
    'status',
    'data_agendada',
  ]) {
    if (d[campo] !== undefined) {
      sets.push(`${campo} = ?`);
      valores.push(d[campo]);
    }
  }

  if (sets.length) {
    db.prepare(
      `UPDATE coletas SET ${sets.join(', ')}, atualizado_em = datetime('now') WHERE id = ?`
    ).run(...valores, id);
  }
  return findById(id);
}

function remove(id) {
  return db.prepare('DELETE FROM coletas WHERE id = ?').run(id).changes > 0;
}

module.exports = { findAll, findById, create, update, remove };
