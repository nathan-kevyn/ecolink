'use strict';

const { z } = require('zod');

const createColetaSchema = z.object({
  usuario_id: z.number().int().positive(),
  ponto_id: z.number().int().positive(),
  material: z.string().min(2).max(80),
  quantidade_kg: z.number().nonnegative().optional(),
  status: z.enum(['agendada', 'concluida', 'cancelada']).optional(),
  data_agendada: z.string().max(40).optional(),
});

const updateColetaSchema = createColetaSchema.partial();

module.exports = { createColetaSchema, updateColetaSchema };
