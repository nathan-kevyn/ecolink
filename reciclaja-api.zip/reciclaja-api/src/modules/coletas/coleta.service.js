'use strict';

const repo = require('./coleta.repository');
const usuarioRepo = require('../usuarios/usuario.repository');
const pontoRepo = require('../pontos/ponto.repository');
const ApiError = require('../../utils/ApiError');

function garantirRelacionados(dados) {
  if (dados.usuario_id !== undefined && !usuarioRepo.findById(dados.usuario_id)) {
    throw ApiError.badRequest(`usuário ${dados.usuario_id} não existe`);
  }
  if (dados.ponto_id !== undefined && !pontoRepo.findById(dados.ponto_id)) {
    throw ApiError.badRequest(`ponto de coleta ${dados.ponto_id} não existe`);
  }
}

function listar(filtros) {
  return repo.findAll(filtros);
}

function buscarPorId(id) {
  const coleta = repo.findById(id);
  if (!coleta) throw ApiError.notFound('Coleta não encontrada');
  return coleta;
}

function criar(dados) {
  garantirRelacionados(dados);
  return repo.create(dados);
}

function atualizar(id, dados) {
  buscarPorId(id);
  garantirRelacionados(dados);
  return repo.update(id, dados);
}

function remover(id) {
  buscarPorId(id);
  repo.remove(id);
}

module.exports = { listar, buscarPorId, criar, atualizar, remover };
