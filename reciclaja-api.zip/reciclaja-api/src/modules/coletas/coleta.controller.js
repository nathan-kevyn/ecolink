'use strict';

const service = require('./coleta.service');

function listar(req, res, next) {
  try {
    // Filtros opcionais: ?usuario_id=1&ponto_id=2&status=agendada
    const filtros = {};
    if (req.query.usuario_id) filtros.usuario_id = Number(req.query.usuario_id);
    if (req.query.ponto_id) filtros.ponto_id = Number(req.query.ponto_id);
    if (req.query.status) filtros.status = req.query.status;
    res.json(service.listar(filtros));
  } catch (err) {
    next(err);
  }
}

function buscar(req, res, next) {
  try {
    res.json(service.buscarPorId(Number(req.params.id)));
  } catch (err) {
    next(err);
  }
}

function criar(req, res, next) {
  try {
    res.status(201).json(service.criar(req.body));
  } catch (err) {
    next(err);
  }
}

function atualizar(req, res, next) {
  try {
    res.json(service.atualizar(Number(req.params.id), req.body));
  } catch (err) {
    next(err);
  }
}

function remover(req, res, next) {
  try {
    service.remover(Number(req.params.id));
    res.status(204).end();
  } catch (err) {
    next(err);
  }
}

module.exports = { listar, buscar, criar, atualizar, remover };
