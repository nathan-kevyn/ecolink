'use strict';

/** Captura qualquer rota não mapeada e devolve 404 em JSON. */
const notFound = (req, res) => {
  res.status(404).json({
    erro: `Rota não encontrada: ${req.method} ${req.originalUrl}`,
  });
};

module.exports = notFound;
