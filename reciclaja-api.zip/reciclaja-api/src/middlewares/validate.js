'use strict';

const ApiError = require('../utils/ApiError');

/**
 * Middleware de validação genérico.
 * Recebe um schema do zod e valida o corpo da requisição (req.body).
 * Em caso de erro, devolve 400 com a lista de campos inválidos.
 * Em caso de sucesso, substitui req.body pelos dados já normalizados.
 */
const validate = (schema) => (req, res, next) => {
  const resultado = schema.safeParse(req.body);

  if (!resultado.success) {
    const detalhes = resultado.error.issues.map((issue) => ({
      campo: issue.path.join('.') || '(corpo)',
      mensagem: issue.message,
    }));
    return next(ApiError.badRequest('Dados inválidos', detalhes));
  }

  req.body = resultado.data;
  next();
};

module.exports = validate;
