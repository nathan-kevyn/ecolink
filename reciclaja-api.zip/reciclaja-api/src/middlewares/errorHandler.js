'use strict';

const { env } = require('../config/env');

/**
 * Tratamento centralizado de erros.
 * Erros de aplicação (ApiError) carregam status próprio; qualquer outro
 * vira 500. Em desenvolvimento, registra o stack no console.
 */
// eslint-disable-next-line no-unused-vars
const errorHandler = (err, req, res, next) => {
  const status = err.status || 500;

  const corpo = { erro: err.message || 'Erro interno do servidor' };
  if (err.details) corpo.detalhes = err.details;

  if (status >= 500) {
    console.error('[ERRO]', err);
    if (env.NODE_ENV !== 'production') corpo.stack = err.stack;
  }

  res.status(status).json(corpo);
};

module.exports = errorHandler;
