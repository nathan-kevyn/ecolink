'use strict';

require('dotenv').config({ quiet: true });
const path = require('node:path');

/**
 * Centraliza as variáveis de ambiente da aplicação.
 * Valores padrão permitem rodar o projeto sem precisar criar um .env.
 */
const env = {
  NODE_ENV: process.env.NODE_ENV || 'development',
  PORT: Number(process.env.PORT) || 3000,
  DB_PATH:
    process.env.DB_PATH ||
    path.join(__dirname, '..', '..', 'data', 'reciclaja.db'),
};

module.exports = { env };
