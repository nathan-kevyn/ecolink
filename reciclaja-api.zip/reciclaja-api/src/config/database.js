'use strict';

const { DatabaseSync } = require('node:sqlite');
const fs = require('node:fs');
const path = require('node:path');
const { env } = require('./env');

// Garante que a pasta do arquivo do banco exista.
fs.mkdirSync(path.dirname(env.DB_PATH), { recursive: true });

/**
 * Usamos o SQLite NATIVO do Node 22+ (módulo `node:sqlite`), que não exige
 * compilação nem servidor de banco — o projeto roda apenas com `npm install`.
 *
 * A API de acesso (db.prepare(sql).run()/.get()/.all()) é IDÊNTICA à do
 * pacote `better-sqlite3`. Para migrar para ele (ou para Postgres/MySQL via
 * outro driver), basta trocar a linha de conexão abaixo — o restante do código
 * (repositories) continua igual:
 *
 *   const Database = require('better-sqlite3');
 *   const db = new Database(env.DB_PATH);
 */
const db = new DatabaseSync(env.DB_PATH);

// Boas práticas: WAL melhora concorrência de leitura/escrita e
// foreign_keys=ON faz o SQLite respeitar as chaves estrangeiras.
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

module.exports = db;
