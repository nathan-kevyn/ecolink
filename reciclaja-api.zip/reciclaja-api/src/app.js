'use strict';

const express = require('express');
const cors = require('cors');
const morgan = require('morgan');

const routes = require('./routes');
const notFound = require('./middlewares/notFound');
const errorHandler = require('./middlewares/errorHandler');

const app = express();

// Middlewares globais
app.use(cors()); // libera acesso do front-end
app.use(express.json()); // body parser JSON
app.use(morgan('dev')); // log das requisições no console

// Rota raiz + health check
app.get('/', (req, res) => {
  res.json({
    api: 'ReciclaJá API',
    versao: '1.0.0',
    descricao: 'Conecta pontos de coleta de recicláveis a usuários.',
    endpoints: ['/api/usuarios', '/api/pontos', '/api/coletas'],
    health: '/api/health',
  });
});

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Rotas de recursos
app.use('/api', routes);

// 404 e tratamento de erros (sempre por último)
app.use(notFound);
app.use(errorHandler);

module.exports = app;
