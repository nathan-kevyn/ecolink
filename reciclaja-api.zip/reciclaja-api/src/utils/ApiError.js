'use strict';

/**
 * Erro de aplicação com código HTTP embutido.
 * Permite que services lancem erros semânticos (404, 409, ...) que o
 * middleware de tratamento de erros converte em respostas JSON adequadas.
 */
class ApiError extends Error {
  constructor(status, message, details) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.details = details;
  }

  static badRequest(message, details) {
    return new ApiError(400, message, details);
  }

  static notFound(message = 'Recurso não encontrado') {
    return new ApiError(404, message);
  }

  static conflict(message) {
    return new ApiError(409, message);
  }
}

module.exports = ApiError;
