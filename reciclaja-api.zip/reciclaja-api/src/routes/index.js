'use strict';

const { Router } = require('express');

const router = Router();

router.use('/usuarios', require('../modules/usuarios/usuario.routes'));
router.use('/pontos', require('../modules/pontos/ponto.routes'));
router.use('/coletas', require('../modules/coletas/coleta.routes'));

module.exports = router;
