-- =====================================================================
--  ReciclaJá — Schema do banco de dados
--  3 entidades:  usuarios  •  pontos_coleta  •  coletas (relação N:N)
-- =====================================================================

-- ----------------------------- USUÁRIOS ------------------------------
-- Pessoas que querem reciclar (possuem cadastro).
CREATE TABLE IF NOT EXISTS usuarios (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  nome          TEXT    NOT NULL,
  email         TEXT    NOT NULL UNIQUE,
  senha_hash    TEXT    NOT NULL,
  telefone      TEXT,
  cidade        TEXT,
  criado_em     TEXT    NOT NULL DEFAULT (datetime('now')),
  atualizado_em TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- -------------------------- PONTOS DE COLETA -------------------------
-- Locais que recebem materiais recicláveis (possuem cadastro).
CREATE TABLE IF NOT EXISTS pontos_coleta (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  nome          TEXT    NOT NULL,
  endereco      TEXT    NOT NULL,
  cidade        TEXT    NOT NULL,
  latitude      REAL,
  longitude     REAL,
  materiais     TEXT    NOT NULL DEFAULT '[]',   -- array JSON: ["papel","vidro"]
  horario       TEXT,
  ativo         INTEGER NOT NULL DEFAULT 1,       -- 0 = inativo, 1 = ativo
  criado_em     TEXT    NOT NULL DEFAULT (datetime('now')),
  atualizado_em TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- ------------------------------ COLETAS ------------------------------
-- Liga um USUÁRIO a um PONTO DE COLETA (o "encontro" da reciclagem).
CREATE TABLE IF NOT EXISTS coletas (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id    INTEGER NOT NULL,
  ponto_id      INTEGER NOT NULL,
  material      TEXT    NOT NULL,
  quantidade_kg REAL    NOT NULL DEFAULT 0,
  status        TEXT    NOT NULL DEFAULT 'agendada',  -- agendada | concluida | cancelada
  data_agendada TEXT,
  criado_em     TEXT    NOT NULL DEFAULT (datetime('now')),
  atualizado_em TEXT    NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id)      ON DELETE CASCADE,
  FOREIGN KEY (ponto_id)   REFERENCES pontos_coleta(id) ON DELETE CASCADE
);

-- Índices para acelerar buscas mais comuns.
CREATE INDEX IF NOT EXISTS idx_coletas_usuario ON coletas(usuario_id);
CREATE INDEX IF NOT EXISTS idx_coletas_ponto   ON coletas(ponto_id);
CREATE INDEX IF NOT EXISTS idx_pontos_cidade   ON pontos_coleta(cidade);
