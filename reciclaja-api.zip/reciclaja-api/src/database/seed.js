'use strict';

require('./init'); // garante schema criado
const db = require('../config/database');
const bcrypt = require('bcryptjs');

console.log('Limpando dados existentes...');
db.exec('DELETE FROM coletas;');
db.exec('DELETE FROM pontos_coleta;');
db.exec('DELETE FROM usuarios;');
// Zera os contadores de AUTOINCREMENT (ignora se a tabela ainda não existir).
try {
  db.exec('DELETE FROM sqlite_sequence;');
} catch (_) {
  /* sem sequência para limpar */
}

const senhaHash = bcrypt.hashSync('senha123', 10);

// ----- USUÁRIOS -----
const insUsuario = db.prepare(
  `INSERT INTO usuarios (nome, email, senha_hash, telefone, cidade)
   VALUES (?, ?, ?, ?, ?)`
);
const usuarios = [
  ['Ana Recicladora', 'ana@email.com', senhaHash, '11999990001', 'São Paulo'],
  ['Bruno Verde', 'bruno@email.com', senhaHash, '11999990002', 'São Paulo'],
  ['Carla Eco', 'carla@email.com', senhaHash, '21999990003', 'Rio de Janeiro'],
];
usuarios.forEach((u) => insUsuario.run(...u));

// ----- PONTOS DE COLETA -----
const insPonto = db.prepare(
  `INSERT INTO pontos_coleta
     (nome, endereco, cidade, latitude, longitude, materiais, horario, ativo)
   VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
);
const pontos = [
  [
    'EcoPonto Centro',
    'Praça da Sé, 100',
    'São Paulo',
    -23.5505,
    -46.6333,
    JSON.stringify(['papel', 'plástico', 'vidro']),
    'Seg-Sex 8h-18h',
    1,
  ],
  [
    'Coleta Vila Madalena',
    'Rua Harmonia, 250',
    'São Paulo',
    -23.5546,
    -46.6896,
    JSON.stringify(['eletrônicos', 'pilhas']),
    'Seg-Sáb 9h-17h',
    1,
  ],
  [
    'ReciclaRio Copacabana',
    'Av. Atlântica, 1500',
    'Rio de Janeiro',
    -22.9711,
    -43.1822,
    JSON.stringify(['metal', 'plástico']),
    'Todos os dias 7h-19h',
    1,
  ],
];
pontos.forEach((p) => insPonto.run(...p));

// ----- COLETAS (relação usuário x ponto) -----
const insColeta = db.prepare(
  `INSERT INTO coletas
     (usuario_id, ponto_id, material, quantidade_kg, status, data_agendada)
   VALUES (?, ?, ?, ?, ?, ?)`
);
const coletas = [
  [1, 1, 'papel', 5.5, 'concluida', '2026-06-01'],
  [1, 2, 'eletrônicos', 2.0, 'agendada', '2026-06-10'],
  [2, 1, 'vidro', 8.0, 'agendada', '2026-06-12'],
  [3, 3, 'plástico', 3.2, 'concluida', '2026-06-03'],
];
coletas.forEach((c) => insColeta.run(...c));

console.log('✔ Seed concluído:');
console.log(`   ${usuarios.length} usuários, ${pontos.length} pontos, ${coletas.length} coletas.`);
console.log('   (senha padrão de todos os usuários: "senha123")');
