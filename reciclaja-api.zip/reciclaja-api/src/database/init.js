'use strict';

const fs = require('node:fs');
const path = require('node:path');
const db = require('../config/database');

/**
 * Lê o schema.sql e cria as tabelas (idempotente: usa IF NOT EXISTS).
 * Pode ser executado isoladamente com `npm run db:init` ou importado
 * pelo server.js para garantir o banco pronto antes de subir a API.
 */
const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
db.exec(schema);

if (require.main === module) {
  console.log('✔ Banco inicializado — tabelas verificadas/criadas.');
}

module.exports = db;
